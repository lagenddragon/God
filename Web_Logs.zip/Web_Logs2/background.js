console.log("[SW] Service worker starting — Chrome 139 fixed v2");

// Context menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "save-irctc-cookies",
    title: "I M NOT ROBOT",
    contexts: ["all"]
  }, () => void chrome.runtime.lastError);
});

// Context menu click → collect cookies + download
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "save-irctc-cookies") {
    collectAndDownloadCookies();
  }
});

// Content script (two clicks) → send message → collect cookies
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action === "collectCookies") {
    collectAndDownloadCookies();
  }
});

// Helper: collect cookies + download JSON
function collectAndDownloadCookies() {
  chrome.cookies.getAll({ domain: "irctc.co.in" }, (cookies) => {
    console.log("[SW] Retrieved cookies:", cookies);
    const json = JSON.stringify(cookies, null, 2);
    const dataUrl =
      "data:application/json;charset=utf-8," + encodeURIComponent(json);

    chrome.downloads.download({
      url: dataUrl,
      filename: "robot.json",
      conflictAction: "overwrite",
      saveAs: false
    }, (downloadId) => {
      console.log("[SW] Download started, ID:", downloadId);
    });
  });
}
